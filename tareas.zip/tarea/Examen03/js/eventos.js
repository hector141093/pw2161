var iniciaApp= function(){
	$banderaBaja=false;
	var Altas= function(){
		$banderaBaja=false;
		alert("entra altas");
		$("h2").html("Altas Almacenes");
		$("#altasAlmacenes").show("fast");
		$(".baja").show("fast");
		$("#enviaAlta").on("click",guardaAlmacen);
		$("#enviaAlta").off("click",borraAlmacen);

	}


	var guardaAlmacen = function()
	{
		$("#enviaAlta").on("click",guardaAlmacen);
		event.preventDefault();
		//alert($("#frmAltaUsuarios").serialize());
		var datos = $("#frmAltaAlmacenes").serialize();		
		var parametros = "accion=altaAlmacen&"+datos+
		                 "&id="+Math.random();
		$.ajax({
			beforeSend:function(){
				console.log("Guardar al usuario");
			},
			cache: false,
			type: "POST",
			dataType: "json",
			url:"php/funciones.php",
			data:parametros,
			success: function(response){
				if(response.respuesta == true )//¬¬
				{
					alert("Guarda");
					$(".capturaUsuario").val("");
					$("#txtId").focus();
				}
				else
				{
					alert("No guarda");
				}
			},
			error: function(xhr,ajax,thrownError){
				console.log("error");
			}
		});
	}

	var LlenarCampos = function(){
		event.preventDefault();
		var datos=$("#frmAltaAlmacenes").serialize();
		
		var parametros = "accion=llenaCampos&"+datos+
		                 "&id="+Math.random();		              
		$.ajax({
			beforeSend:function(){
				
			},
			cache: false,
			type: "POST",
			dataType: "json",
			url:"php/funciones.php",
			data:parametros,
			success: function(response){
				if(response.respuesta && $banderaBaja)//¬¬
				{
					$(".baja").show("fast");
					$("#txtId").val(response.id);
					$("#txtNombre").val(response.nom);
					$("#txtDireccion1").val(response.dir1);
					$("#txtDireccion2").val(response.dir2);
					$("#txtCP").val(response.CP);
					$("#txtLocalidad").val(response.localidad);
					$("#txtProvincia").val(response.provincia);					
				}
				else
				{	
				
				}
			},
			error: function(xhr,ajax,thrownError){
				console.log("error");
			}
		});
	}
	var Bajas= function (){	
		$banderaBaja=true;
		alert("entra bajas");
		$("h2").html("Bajas Almacenes");
		$("#altasAlmacenes").show("fast");		
		$(".baja").hide("fast");		
		$("#enviaAlta").off("click",guardaAlmacen);
		$("#enviaAlta").on("click",borraAlmacen);
		$("#txtId").on("focusout",LlenarCampos);
	}
	var borraAlmacen = function()
	{
		event.preventDefault();			
		var parametros=$("#frmAltaAlmacenes").serialize();
		var parametros = "accion=bajaAlmacen&"+parametros+
		                 "&id="+Math.random();
		$.ajax({
			beforeSend:function(){
				console.log("Guardar al usuario");
			},
			cache: false,
			type: "POST",
			dataType: "json",
			url:"php/funciones.php",
			data:parametros,
			success: function(response){
				if(response.respuesta && $banderaBaja)//¬¬
				{
					alert("Borra");
				}
				else
				{
					alert("No Borra");
				}
			},
			error: function(xhr,ajax,thrownError){
				console.log("error");
			}
		});
	}
	var Consultas = function(){
		alert("consultas");
		$("#altasAlmacenes").hide("slow");
		$("#consultas").show("slow");
		var parametros= "accion=consultaAlmacenes"+"&id="+Math.random();
		$.ajax({
			cache: false,
			type: "POST",
			dataType: "json",
			url: "php/funciones.php",
			data: parametros,
			success: function(response){
				$("#tablaAlmacenes").html("");
				$("#tablaAlmacenes").append(response.renglones);
			},
			error: function(xhr,ajaxOptions,throws){
				console.log("Ha ocurrido un error");
			}
		});
	}

	var Cambios = function(){
		$(".baja").show("fast");
		$("#txtId").on("focusout",LlenarCampos);
		alert("cambios");
		$("#altasAlmacenes").show("slow");
		$datos=("frmAltaAlmacenes").serialize();
		var parametros= "opcion=Cambios"+$datos+"&id="+Math.random();
		$.ajax({
			cache: false,
			type: "POST",
			dataType: "json",
			url: "php/cambios.php",
			data: parametros,
			success: function(response){
				alert("se hizo el cambio");
			},
			error: function(xhr,ajaxOptions,throws){
				console.log("Ha ocurrido un error");
			}
		});
	}
	$("#btnAltas").on("click",Altas);
	$("#btnBajas").on("click",Bajas);
	$("#btnConsultas").on("click",Consultas);
	$("#btnCambios").on("click",Cambios);
}
$(document).on("ready",iniciaApp);