<?php
include("utilerias.php");

	function altaAlmacen(){
		$id=GetSQLValueString($_POST["txtId"],"text");
		$nom=GetSQLValueString($_POST["txtNombre"],"text");
		$dir1=GetSQLValueString($_POST["txtDireccion1"],"text");
		$dir2=GetSQLValueString($_POST["txtDireccion2"],"text");
		$CP=GetSQLValueString($_POST["txtCP"],"text");
		$localidad=GetSQLValueString($_POST["txtLocalidad"],"text");
		$provincia=GetSQLValueString($_POST["txtProvincia"],"text");

		$respuesta=false;
		$conexion=mysql_connect("localhost","root","");
		mysql_select_db("examen");
		mysql_query("SET NAMES utf8");
		$guardar=sprintf("insert into almacenes values(%s,%s,%s,%s,%s,%s,%s)",$id,$nom,$dir1,$dir2,$CP,$localidad,$provincia);
		mysql_query($guardar);

		if(mysql_affected_rows()>0){
			$respuesta=true;
		}
		$salidaJSON=array('respuesta'=> $respuesta);
		print json_encode($salidaJSON);

	}
	function bajaAlmacen(){
		$id = GetSQLValueString($_POST["txtId"],"text");
		$respuesta=false;
		$conexion=mysql_connect("localhost","root","");
		mysql_select_db("examen");
		mysql_query("SET NAMES utf8");
		$consulta=sprintf("delete from almacenes where id=%s limit 1",$id);
		mysql_query($consulta);
		if(mysql_affected_rows()>0){
			$respuesta=true;
		}
		$salidaJSON=array('respuesta'=>$respuesta);
		print json_encode($salidaJSON);
	}

	function llenaCampos(){
		$id = GetSQLValueString($_POST["txtId"],"text");
		$respuesta=false;
		$conexion = mysql_connect("localhost","root","");
		mysql_select_db("examen");
		mysql_query("SET NAMES utf8"); //caracteres latinos
		$consulta = sprintf("select * from almacenes where id=%s limit 1",$id);
		$resconsulta= mysql_query($consulta);
		if(mysql_num_rows($resconsulta)>0){ //para saber si hay datos
			$respuesta= true;
			//rescatar valores
			$fila=mysql_fetch_array($resconsulta);
			//$nom= $fila[1];
			$id=$fila["id"];
			$nom= $fila["nombre"];
			$dir1=$fila["direccion1"];
			$dir2=$fila["direccion2"];
			$CP=$fila["CP"];
			$localidad=$fila["localidad"];
			$provincia=$fila["provincia"];
	}

	$salidaJSON = array ('respuesta'=> $respuesta,'id'=>$id,'nom'=>$nom,'dir1'=>$dir1,
						'dir2'=>$dir2,'CP'=>$CP,'localidad'=>$localidad,'provincia'=>$provincia);
	print json_encode ($salidaJSON);
	}

	function consultaAlmacenes()
	{
		$respuesta=false;
		$conexion = mysql_connect("localhost","root","");
		mysql_select_db("examen");
		mysql_query("SET NAMES utf8"); //caracteres latinos
		$consulta = sprintf("select * from almacenes order by id");
		$resconsulta= mysql_query($consulta);
		$tabla="";
		if(mysql_num_rows($resconsulta)>0){ //para saber si hay datos
			$respuesta= true;
			//armar tabla
			$tabla = "<tr><th>Id</th><th>Nombre</th><th>Código Postal</th><th>Dir. 1</th>"+
						"<th>Dir. 2</th><th>Localidad</th><th>Provincia</th></tr>";
			//extraer datos
			while($fila=mysql_fetch_array($resconsulta)){
				$tabla.="<tr>";
				$tabla.="<td>".$fila["id"]."</td>";
				$tabla.="<td>".$fila["nombre"]."</td>";
				$tabla.="<td>".$fila["direccion1"]."</td>";
				$tabla.="<td>".$fila["direccion2"]."</td>";
				$tabla.="<td>".$fila["CP"]."</td>";
				$tabla.="<td>".$fila["localidad"]."</td>";
				$tabla.="<td>".$fila["provincia"]."</td>";
				$tabla.="</tr>";
			}
		}else{
			$tabla= "<tr><td>Sin datos</td><tr>";
		}
		$salidaJSON =array('respuesta'=> $respuesta,
							'renglones'=> $tabla);
		print json_encode($salidaJSON);
	}

	$accion=$_POST["accion"];
	switch ($accion) {
		case 'altaAlmacen':
			altaAlmacen();
			# code...
			break;
		case 'llenaCampos':
			llenaCampos();
			break;
		case 'bajaAlmacen':
			  bajaAlmacen();
			  break;
		case 'consultaAlmacenes':
			   consultaAlmacenes();
			  	# code...
			  	break;
		default:
			# code...
			break;
	}
?>