<?php 

include("utilerias.php");

function Cambios(){
	$respuesta =false;
		$id=GetSQLValueString($_POST["txtId"],"text");
		$nom=GetSQLValueString($_POST["txtNombre"],"text");
		$dir1=GetSQLValueString($_POST["txtDireccion1"],"text");
		$dir2=GetSQLValueString($_POST["txtDireccion2"],"text");
		$CP=GetSQLValueString($_POST["txtCP"],"text");
		$localidad=GetSQLValueString($_POST["txtLocalidad"],"text");
		$provincia=GetSQLValueString($_POST["txtProvincia"],"text");

	$conexion = mysql_connect("localhost","root","");
	mysql_select_db("examen");
	mysql_query("SET NAMES utf8"); //caracteres latinos
	$consulta= sprintf("update almacenes SET id=%s, nombre=%s,direcion1=%s,direcion2=%s,
						 CP=%s,localidad=%s,provincia=%s WHERE id=%s",$id,$nom,$dir1,
						 $dir2,$CP,$localidad,$provincia);
	$resconsulta= mysql_query($consulta);
	if(mysql_affected_rows()>0){
		$respuesta=true;
	}
	$salidaJSON = array ('respuesta' => $respuesta);
	print json_encode($salidaJSON);
}

$opcion =$_POST["opcion"];
switch ($opcion) {
	case 'Cambios':
		Cambios();
		break;
	
	default:
		# code...
		break;
}
 ?>